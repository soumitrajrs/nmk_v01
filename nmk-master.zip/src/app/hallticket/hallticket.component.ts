import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'hallticket',
  templateUrl: './hallticket.component.html',
  styleUrls: ['./hallticket.component.scss']
})
export class HallticketComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
